window.WHISPER_TEST_BUILD = Object.freeze({
  "title": "Whisper до 1.3J — контроль",
  "id": "before13j-control-r1",
  "sourceCommit": "6ca7510fb9134198c3244e47d08a698d9d27eb57",
  "runtimeCommit": "6ca7510fb9134198c3244e47d08a698d9d27eb57"
});
