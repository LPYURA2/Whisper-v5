window.WHISPER_TEST_BUILD = Object.freeze({
  "title": "Whisper 1.3J-1 — диагностика WS",
  "id": "accepted13j-diagnostic-r1",
  "sourceCommit": "9657faaaa59c31d3b3c2c489fc9a20a61e6fe5b0",
  "runtimeCommit": "9657faaaa59c31d3b3c2c489fc9a20a61e6fe5b0"
});
